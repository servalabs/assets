MODULAR SURVEILLANCE INFOGRAPHIC CARD PACK

CORE CARDS
01 Multi-Source Feeds
02 Ingest / Recording Node
03 Network Switch
04 AI Processing Server
05 AI Analytics & Situational Awareness
06 Air-Gapped LAN
07 Commander Room
08 Team Leader Room
09 Communicator Room
10 Enemy Vehicle Detection
11 Friendly Vehicle Detection
12 Human Detection
13 Aircraft / Drone Detection
14 Live Geo-Tracking
15 Simplified Security Footer

SOURCE TILES
Fixed CCTV, PTZ Cameras, Drone/UAV, Vehicle Cameras, Thermal Cameras,
Body Cameras, Radar/Sensors, Observation Tower, And More Sources

ANALYTICS TILES
Enemy Vehicle, Friendly Vehicle, Human, Aircraft/Drone,
Suspicious/Unknown, Live Geo-Tracking, Tracking Map & Radar

CONNECTORS
Right Arrow, Down Arrow, Dashed LAN Connector

SIMPLIFIED FOOTER
AIR-GAPPED SYSTEM | NO INTERNET | NO WI-FI | NO BLUETOOTH |
PHYSICALLY ISOLATED | BUILT FOR SECURITY. BUILT FOR THE MISSION.
